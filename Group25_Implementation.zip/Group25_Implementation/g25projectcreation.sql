use fi127600_db;

/* The table creation for Employee, where EmployeeID is the 
primary key */

CREATE TABLE Employee (
	Employee_ID		CHAR(5) NOT NULL,
	firstName		VARCHAR(20),
	lastName		VARCHAR(20),
	Position		VARCHAR(20),
	ManagerID		CHAR(5),
CONSTRAINTS Employee_PK PRIMARY KEY(EmployeeID)
);

CREATE TABLE Auditorium (
	Auditorium_Num 	VARCHAR(20) NOT NULL,
	Hall_Location	VARCHAR(5),
	Max_Capacity	VARCHAR(300),
	Movie_Title		VARCHAR(50),
	Num_Seats_Filled VARCHAR(300),
CONSTRAINT Auditorim_PK PRIMARY KEY(Auditorium_Num)
);

CREATE TABLE Movie (
	Title		VARCHAR(50) NOT NULL,
	Rating		VARCHAR(4),
	Duration	INTEGER,
	Genre		VARCHAR(20),
	Auditorium_Num	VARCHAR(20) NOT NULL,
CONSTRAINT Movie_PK PRIMARY KEY(Title),
CONSTRAINT Movie_FK FOREIGN KEY(Auditorium_Num) 
	REFERENCES Auditorium(Auditorium_Num)
);

CREATE TABLE Customer (
	Reciept_no 		VARCHAR(20) NOT NULL,
	Employee_ID 	CHAR(5) NOT NULL,
	Ticket_no		VARCHAR(20)
CONSTRAINT Customer_PK PRIMARY KEY(Reciept_no),
CONSTRAINT Customer_FK FOREIGN KEY(Employee_ID) 
	REFERENCES Employee(Employee_ID)
);

CREATE TABLE Ticket (
	Ticket_no		VARCHAR(20) NOT NULL,
	Movie_Title		VARCHAR(50) NOT NULL,
	Date_Purchased	DATE,
	Total_Sold		INTEGER,
	Num_Available	INTEGER,
	Time_Showing	TIME,
	Employee_ID		CHAR(5) NOT NULL,
	Auditorium_Num	VARCHAR(20) NOT NULL,
CONSTRAINT Ticket_PK PRIMARY KEY (Ticket_no, Movie_Title, Time_Showing),
CONSTRAINT Ticket_FK FOREIGN KEY(Employee_ID) 
	REFERENCES Employee(Employee_ID),
CONSTRAINT Ticket_FK2 FOREIGN KEY(Auditorium_Num)
		REFERENCES Auditorium(Auditorium_Num)
);

commit;