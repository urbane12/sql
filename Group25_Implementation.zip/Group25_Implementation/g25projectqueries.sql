/* queries used for the database */

SELECT * FROM auditorium;
SELECT * FROM Ticket;
SELECT * FROM Employee;
SELECT * FROM Movies;
SELECT * FROM Customer;


SELECT firstName, lastName, Position FROM Employee;
SELECT Auditorium_Num, Movie_Title, Num_Seats_Filled FROM Auditorium;
SELECT Reciept_no, Employee_ID, Ticket_no FROM Customer;
SELECT Title, Rating, Duration, Auditorium_No FROM Movies;
SELECT Movie_Title, Time_Showing FROM Ticket;


UPDATE Ticket
SET Time_Showing = ‘23:24:47’
Where Movie_Title = ‘Trolls’;


UPDATE Auditorium
SET Num_Seats_Filled = ‘51’
Where Movie_Title = ‘The Magnificent Seven’;


UPDATE Auditorium
SET Num_Seats_Filled = ‘30’
Where Movie_Title = ‘Miss Peregrine’;


UPDATE Ticket
SET Time_Showing = ‘11:11:11’
Where Movie_Title = ‘Doctor Strange’;


UPDATE Ticket
SET Time_Showing = ‘11:43:00’
Where Movie_Title = ‘The Accountant’;
