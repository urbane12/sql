/* values for the employee table */

INSERT INTO Employee VALUES("16812", "Erika", "Kim", "Cashier", "");
INSERT INTO Employee VALUES("49756", "Alexander", "Miltonah", "Manager", "49756");
INSERT INTO Employee VALUES("18626", "Michael", "Ashter", "Concessions", "");
INSERT INTO Employee VALUES("60320", "Jessica", "Winston", "Usher", "");
INSERT INTO Employee VALUES("76916", "Barry", "Allen", "Usher", "");
INSERT INTO Employee VALUES("91662", "Christopher", "Ilyich", "Cashier", "");
INSERT INTO Employee VALUES("81369", "Haley", "Parker", "Concessions", "");
INSERT INTO Employee VALUES("58418", "Jackson", "Bach", "Usher", "");
INSERT INTO Employee VALUES("61662", "Ivan", "Peterson", "Concessions", "");
INSERT INTO Employee VALUES("55938", "Tiffany", "Dvorak", "Cashier", "");
INSERT INTO Employee VALUES("72879", "Jacqueline", "Hernan", "Manager", "72879");
INSERT INTO Employee VALUES("52981", "Emily", "Vivaldi", "Concessions", "");
INSERT INTO Employee VALUES("43777", "Emma", "Granger", "Cashier", "");
INSERT INTO Employee VALUES("70873", "Michael", "Hemingway", "Usher", "");
INSERT INTO Employee VALUES("33132", "Claudia", "Lafayette", "Cashier", "");
INSERT INTO Employee VALUES("56477", "Wendy", "Rodriguez", "Usher", "");
INSERT INTO Employee VALUES("87420", "Alexandra", "Williams", "Concessions", "");
INSERT INTO Employee VALUES("57099", "Jonathan", "Watson", "Concessions", "");
INSERT INTO Employee VALUES("16119", "Rodrigo", "Garcia", "Cashier", "");
INSERT INTO Employee VALUES("38863", "Chen", "Parker", "Manager", "");

/*values for the auditorium table */

INSERT INTO Auditorium VALUES(“1”, “1”, “100”,”Doctor Strange”,”100”);
INSERT INTO Auditorium VALUES(“2”, “1”, “66”,”Trolls”,”40”);
INSERT INTO Auditorium VALUES(“3”, “1”, “60”,”Almost Christmas”,”40”);
INSERT INTO Auditorium VALUES(“4”, “1”, “66”,”Arrival”,”45”);
INSERT INTO Auditorium VALUES(“5”, “1”, “50”,”Hacksaw Ridge”,”50”);
INSERT INTO Auditorium VALUES(“6”, “1”, “66”,”Shut In”,”60”);
INSERT INTO Auditorium VALUES(“7”, “1”, “66”,”Boo! A Madea Halloween”,”40”);
INSERT INTO Auditorium VALUES(“8”, “1”, “66”,”Inferno”,”66”);
INSERT INTO Auditorium VALUES(“9”, “1”, “100”,”Jack Reacher: Never Go Back”,”66”);
INSERT INTO Auditorium VALUES(“10”, “1”, “80”,”The Accountant”,”66”);
INSERT INTO Auditorium VALUES(“11”, “2”, “66”,”Ouija”,”66”);
INSERT INTO Auditorium VALUES(“12”, “2”, “50”,”The Girl on The Train”,”60”);
INSERT INTO Auditorium VALUES(“13”, “2”, “66”,”Storks”,”30”);
INSERT INTO Auditorium VALUES(“14”, “2”, “80”,”Keeping up with the Joneses”,”40”);
INSERT INTO Auditorium VALUES(“15”, “2”, “66”,”Deepwater Horizon”,”60”);
INSERT INTO Auditorium VALUES(“16”, “2”, “66”,”Kevin Hart: What Now”,”66”);
INSERT INTO Auditorium VALUES(“17”, “2”, “80”,”Sully”,”66”);
INSERT INTO Auditorium VALUES(“18”, “2”, “66”,”Miss Peregrine”,”35”);
INSERT INTO Auditorium VALUES(“19”, “2”, “60”,”Finding Dory”,”60”);
INSERT INTO Auditorium VALUES(“20”, “2”, “66”,”The Magnificent Seven”,”50”);

/*values for the movie table */

INSERT INTO Movie VALUES("Doctor Strange", "PG13", 113, "Fantasy", "1");
INSERT INTO Movie VALUES("Trolls", "PG", 96, "Fantasy", "2");
INSERT INTO Movie VALUES("Hacksaw Ridge", "R", 112, "Drama", "5");
INSERT INTO Movie VALUES("Inferno", "R", 124, "Mystery", "8");
INSERT INTO Movie VALUES("Jack Reacher", "R", 102, "Mystery", "9");
INSERT INTO Movie VALUES("The Accountant", "PG", 95, "Crime", "10");
INSERT INTO Movie VALUES("Shut In", "PG", 94, "Drama", "6");
INSERT INTO Movie VALUES("Arrival", "PG", 82, "Science Fiction", "4");
INSERT INTO Movie VALUES("Almost Christmas", "PG13", 86, "Comedy", "3");
INSERT INTO Movie VALUES("Ouija", "R", 95, "Horror", "11");
INSERT INTO Movie VALUES("The Girl on The Train", "PG13", 92, "Mystery", "12");
INSERT INTO Movie VALUES("Miss Peregrine", "PG13", 102, "Fantasy", "18");
INSERT INTO Movie VALUES("Storks", "PG", 122, "Fantasy", "13");
INSERT INTO Movie VALUES("Keeping up with the Joneses", "PG", 102, "Comedy", "14");
INSERT INTO Movie VALUES("Deepwater Horizon", "PG13", 96, "Thriller", "15");
INSERT INTO Movie VALUES("Kevin Hart: What Now", "PG", 104, "Documentary", "16");
INSERT INTO Movie VALUES("Sully", "PG13", 93, "Drama", "17");
INSERT INTO Movie VALUES("Moonlight", "PG13", 87, "Drama", "7");
INSERT INTO Movie VALUES("The Magnificent Seven", "PG", 96, "Action", "20");
INSERT INTO Movie VALUES("Finding Dory", "PG", 105, "Adventure", "19");

/* values for the customer table */
INSERT INTO Customer VALUES("309", "16119", "22");
INSERT INTO Customer VALUES("418", "43777", "10");
INSERT INTO Customer VALUES("922", "43777", "7");
INSERT INTO Customer VALUES("52", "16812", "9");
INSERT INTO Customer VALUES("112", "55938", "18");
INSERT INTO Customer VALUES(“372”, “91622”, “22”);
INSERT INTO Customer VALUES(“113”, “49756”, “72”);
INSERT INTO Customer VALUES(“981”, “18626”, “86”);
INSERT INTO Customer VALUES(“473”, “91662”, “11”);
INSERT INTO Customer VALUES(“167”, “49756”, “23”);
INSERT INTO Customer VALUES(“246”,”16812”,”52”);
INSERT INTO Customer VALUES(“471”,”38863”,”24”);
INSERT INTO Customer VALUES(“456”,”16119”,”12”);
INSERT INTO Customer VALUES(“213”,”58418”,”20”);
INSERT INTO Customer VALUES(“364”,”87420”,”25”);
INSERT INTO Customer VALUES(“256”,”58418”,”24”);
INSERT INTO Customer VALUES(“512”,”43777”,”1”);
INSERT INTO Customer VALUES(“291”,”58418”,”14”);
INSERT INTO Customer VALUES(“128”,”91662”,”2”);
INSERT INTO Customer VALUES(“64”,”43777”,”17”);

/*values for the ticket table */
INSERT INTO Ticket VALUES("1003","Doctor Strange", "2016-11-02", 80, 20, "13:00:00", "60320", "1" );
INSERT INTO Ticket VALUES("100", "Trolls", "2016-11-01", 10, 50, "12:55:43", "49756", "2");
INSERT INTO Ticket VALUES("44", "Hacksaw Ridge", "2016-11-09", 30, 50, "15:43:34", "60320", "3");
INSERT INTO Ticket VALUES("203", "Inferno", "2016-11-03", 20, 30, "17:05:45", "49756", "4");
INSERT INTO Ticket VALUES("36328", "Jack Reacher", "2016-10-20", 40, 10, "19:20:00", "76916", "5");
INSERT INTO Ticket VALUES("983", "The Accountant", "2016-11-01", 60, 0, "21:00:01", "76916", "6");
INSERT INTO Ticket VALUES("0933", "Shut In", "2016-10-10", 10, 40, "18:03:30", "58418", "7");
INSERT INTO Ticket VALUES("98", "Arrival", "2016-11-12", 30, 5, "17:04:33", "72879", "8");
INSERT INTO Ticket VALUES("4622", "Almost Christmas", "2016-11-03", 30, 30, "19:07:45", "38863", "9");
INSERT INTO Ticket VALUES("8433", "Ouija", "2016-10-31", 30, 0, "13:13:13", "72879", "10");
INSERT INTO Ticket VALUES("462", "The Girl on The Train", "2016-10-31", 20, 10, "17:05:00", "70873", "10");
INSERT INTO Ticket VALUES("3", "Miss Peregrine", "2016-11-03", 5, 25, "12:20:43", "70873", "9");
INSERT INTO Ticket VALUES("352", "Storks", "2016-11-09", 22, 13, "12:05:55", "56477", "8");
INSERT INTO Ticket VALUES("5543", "Keeping up with the Joneses", "2016-11-10", 2, 48, "14:33:59", "56477","7");
INSERT INTO Ticket VALUES("243", "Deepwater Horizon", "2016-11-01", 45, 15, "00:01:11", "56477", "6");
INSERT INTO Ticket VALUES("1", "Kevin Hart: What Now", "2016-11-07", 10, 40, "13:37:28", "70873", "5");
INSERT INTO Ticket VALUES("32", "Sully", "2016-11-03", 25, 25, "12:30:20", "56477", "4");
INSERT INTO Ticket VALUES("527", "Moonlight", "2016-11-09", 79, 1, "10:20:20", "76916", "3");
INSERT INTO Ticket VALUES("873", "The Magnificent Seven", "2016-11-02", 30, 30, "12:12:12", "76916", "2");
INSERT INTO Ticket VALUES("24", "Finding Dory", "2016-11-01", 50, 50, "17:45:09", "49756", "1");

commit;

